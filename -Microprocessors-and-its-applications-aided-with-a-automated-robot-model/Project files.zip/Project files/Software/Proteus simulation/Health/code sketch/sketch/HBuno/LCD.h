#ifndef LCD_H
#define LCD_H

#include <LiquidCrystal.h>
LiquidCrystal lcd(13, 12, 11, 10, 9, 8);


#endif
